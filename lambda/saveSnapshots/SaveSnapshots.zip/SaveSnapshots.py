import json
import boto3
from datetime import date

#S3 resources
bucketname = 'ec2-instances-todelete' #bucket where the list of ec2 isntaces are stored
srcfile = 'list-ec2.txt'
destfile = '/tmp/list-ec2.txt'
s3 = boto3.resource('s3')
s3.Bucket(bucketname).download_file(srcfile, destfile)

#EC2 resources
ec2 = boto3.client('ec2')
today = date.today()
prefix=str(today.month)+'/'+str(today.day)+'/'+str(today.year)

def lambda_handler(event, context):
    try:
        
        with open(destfile, 'r') as f:
            instancesList = [line.strip() for line in f]
            
        for instanceid in instancesList:
            
            tags = ec2.describe_tags(
                Filters=[
                    {
                        'Name':'resource-id',
                        'Values':[instanceid]
                    },
                    {
                        'Name':'key',
                        'Values':['Name']
                    }

                    ])
                
            InstanceName = tags['Tags'][0]['Value']
            
            print(InstanceName)

            ec2.create_snapshots(
                
                Description='Snapshot from: '+ instanceid,
                InstanceSpecification={
                    'InstanceId': instanceid,
                    'ExcludeBootVolume': False
                    
                },    TagSpecifications=[
                    {
                        'ResourceType': 'snapshot',
                        'Tags': [
                            {   
                                'Key': 'Name',
                                'Value': InstanceName+"-"+prefix
                            }
                        ]
                    }
                ]
            )
            
        ec2.terminate_instances(InstanceIds=instancesList)

    except Exception as e:
        raise e